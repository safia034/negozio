package com.mycompany.negozio;

import eccezioni.EccezioneAppendiabitiNonValido;
import eccezioni.EccezionePosizioneNonValida;
import eccezioni.EccezionePosizioneOccupata;
import eccezioni.EccezionePosizioneVuota;
import eccezioni.FileException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import utilita.ConsoleInput;
import utilita.Menu;
import utilita.Ordinatore;

public class App
{
    public static void main(String[] args) throws IOException, FileNotFoundException, ClassNotFoundException, EccezionePosizioneNonValida, EccezionePosizioneVuota, EccezionePosizioneOccupata
    {
        
      //  Abito l1 = new Abito(0, "t", 20, "ftds", "f", "we");
     //  Abito l2 = new Abito(0, "d", 0, "marca", "taglia", "colore");
        
        String[] vociMenu;
        int appendiabito = 0;
        int numeroVoci = 11;
        vociMenu = new String[numeroVoci];
        Menu menu;
        int voceScelta;
        Magazzino m1 = new Magazzino(); 
        int esito;
        ConsoleInput tastiera = new ConsoleInput();
        int prezzo;
        String taglia = null, marca, colore = null, tipo;
        int idAbito;
        Abito ab = null ;
        int appendiabiti = 0, posizione = 0;
        String[] elencoaMarcaColore;
        Abito[] AbitiPresenti;
        String nomeFile = "appendiabiti.csv";
        String nomeFileBinario = "Magazzino.bin";
        
        vociMenu[0] = "\t--> Esci";
        vociMenu[1] = "\t--> Visualizza tutti i Appendiabiti presenti";
        vociMenu[2] = "\t--> Aggiungi Appendiabito";
        vociMenu[3] = "\t--> Visualizza Appendiabiti(appendiabiti, posizione)";
        vociMenu[4] = "\t--> Elimina appendiabiti (appendiabiti, posizione)";
        vociMenu[5] = "\t--> Mostra Abiti di un marca";
        vociMenu[6] = "\t--> Mostra abiti presenti in ordine alfabetico di marca";
        vociMenu[7] = "\t--> Esporta i appendiabiti su file CSV";
        vociMenu[8] = "\t--> Importa i appendiabit da file CSV";
        vociMenu[9] = "\t--> salva dati Magazzino";
        vociMenu[10] = "\t--> carica dati magazzino";
        menu = new Menu(vociMenu);
        
        do
        {
            System.out.println("Menu:");
            voceScelta = menu.sceltaMenu();
            switch (voceScelta)
            {
                case 0: 
                    System.out.println("Arrivederci!");    
                    break;
                case 1:
                    System.out.println(m1.toString());
                    break;
                case 2:
                  try{
                    
                    System.out.println("marca-->");
                    marca = tastiera.readString();
                    System.out.println("Tipo-->");
                    tipo = tastiera.readString();
                    System.out.println("taglia -->");
                    taglia=tastiera.readString();
                    System.out.println("colore-->");
                    colore = tastiera.readString();
                      
                     do{
                       // elencoMarcaColore
                       try
                       {
                        System.out.println("appendiabito--");
                        appendiabiti=tastiera.readInt();
                        break;
                       }
                       catch(NumberFormatException e)
                       {
                            System.out.println("Errore! Devi inserire un numero!");
                       }
          
                    }while (true) ;
                    do{
                       // elencoMarcaColore
                       try
                       {
                        System.out.println("Posizione--");
                        posizione=tastiera.readInt();
                        break;
                       }
                       catch(NumberFormatException e)
                       {
                            System.out.println("Errore! Devi inserire un numero!");
                       }
          
                    }while (true) ;                     
                    do
                    {
                        try
                        {
                            System.out.println(" idAbito --> ");
                            idAbito = tastiera.readInt();
                            break;
                        }
                        catch (NumberFormatException e)
                        {
                            System.out.println("Errore! Devi inserire un numero!");
                        }
                    } while(true);
                    do
                    {
                        try
                        {
                            System.out.println("prezzo --> ");
                            prezzo =  tastiera.readInt();
                            break;
                        }
                        catch (NumberFormatException e)
                        {
                            System.out.println("Errore! Devi inserire un numero!");
                        }
                    } while(true);
                    try
                    {
                        m1.setAbito(new Abito(idAbito, tipo, prezzo, marca, taglia, colore), appendiabito, posizione);
                            System.out.println("appendiabito aggiunto correttamente");
                    }
                     catch (EccezioneAppendiabitiNonValido ex) 
                        {
                             System.out.println("appendiabito inesistente");
                        } 
                    }
                    catch(IOException e)
                    {
                        System.out.println("Impossibile leggere da tastiera!");
                    }
           
                    break;


                case 3:
            
                 try 
                    {
                        do
                        {
                            try
                            {
                                System.out.println("appendiabito (0..4) --> ");
                                appendiabito=tastiera.readInt();
                                break; //se input ok, esci dal ciclo
                            }
                            catch (NumberFormatException e)
                            {
                                System.out.println("Errore! Devi inserire un numero!");
                            }  
                        }while(true); 
                        
                        do
                        {
                            try
                            {
                                    System.out.println("Posizione (0..14) --> ");
                                    posizione=tastiera.readInt();
                                break; //se input ok, esci dal ciclo
                            }
                            catch (NumberFormatException e)
                            {
                                System.out.println("Errore! Devi inserire un numero!");
                            }  
                        }while(true);  
                        ab=m1.getAbito(appendiabito, posizione);
                        System.out.println("abito cercato: "+ab.toString());
                    } 
                    catch (EccezioneAppendiabitiNonValido ex) 
                    {
                         System.out.println("appendiabito inesistente");
                    } 
                    catch (EccezionePosizioneNonValida ex) 
                    {
                          System.out.println("Posizione inesistente");
                    } 
                    catch (EccezionePosizioneVuota ex) 
                    {
                        System.out.println("abito non trovato!");
                    }
                    catch (IOException e)
                    {
                        System.out.println("Impossibile leggere da tastiera!");
                    }
                    break;
                 /*   System.out.println("Ripiano (0..4) --> ");
                    appendiabiti = tastiera.readInt();
                    System.out.println("Posizione (0..9) --> ");
                    posizione = tastiera.readInt();
                    ab = m1.getAbito(ab);
                    System.out.println(ab.toString());
                    break;*/
                case 4:
                    
                   try
                    {
                        do
                        {
                            try
                            {
                                System.out.println("appendiabiti (0..4) --> ");
                                appendiabiti=tastiera.readInt();
                                break; //se input ok, esci dal ciclo
                            }
                            catch (NumberFormatException e)
                            {
                                System.out.println("Errore! Devi inserire un numero!");
                            }  
                        }while(true); 
                        
                        do
                        {
                            try
                            {
                                    System.out.println("Posizione (0..14) --> ");
                                    posizione=tastiera.readInt();
                                break; //se input ok, esci dal ciclo
                            }
                            catch (NumberFormatException e)
                            {
                                System.out.println("Errore! Devi inserire un numero!");
                            }  
                        }while(true);  
                        m1.rimuoviAbito(appendiabito, posizione);
                        System.out.println("Volume rimosso correttamente");
                    } 
                     catch (EccezioneAppendiabitiNonValido ex) 
                    {
                         System.out.println("appendiabito inesistente");
                    } 
                    catch (EccezionePosizioneNonValida ex) 
                    {
                          System.out.println("Posizione inesistente");
                    } 
                    catch (EccezionePosizioneVuota ex) 
                    {
                          System.out.println("Posizione già vuota. Nessun libro è stato rimosso.");
                    }
                    catch (IOException ex)
                    {
                        System.out.println("Impossibile acquisire da tastiera");
                    }    
                    
                    
                    /*System.out.println("prezzo --> ");
                    prezzo = tastiera.readInt();
                    System.out.println("Posizione (0..9) --> ");
                    posizione = tastiera.readInt();
                    m1.eliminaAbito(posizione,appendiabiti);
                    System.out.println("Abito eliminato correttamente");
                    break;*/
                case 5:
                  try
                    {
                        
                        System.out.println("marca --> ");
                        marca=tastiera.readString();
                        elencoaMarcaColore=m1.elencoMarcaColore(marca);
                        if(elencoaMarcaColore==null)
                            System.out.println("Nessun libro presente");
                        else
                        {
                            for(int i=0;i<elencoaMarcaColore.length;i++)
                            {
                                System.out.println(elencoaMarcaColore[i]);
                            }
                        }   
                    }
                    catch (IOException e)
                    {
                        System.out.println("Impossibile leggere da tastiera1");
                    }
                    
                    
                    
                    /*System.out.println("Marca --> ");
                    marca = tastiera.readString();
                    elencoTagliaMarca = m1.getAbitiMarca(marca);
                    for (String s : elencoTagliaMarca)
                    {
                        System.out.println(s);
                    }*/
                    break;
                case 6:
                    AbitiPresenti = m1.getAbitiOrdinati();
                    AbitiPresenti=Ordinatore.selectionSortCrescenteAbiti(AbitiPresenti);
                    for(int i=0;i<AbitiPresenti.length;i++)
                    {
                        System.out.println(AbitiPresenti[i].toString());
                    }
                    break;
                    case 7:
                      try 
                    {
                        m1.esportaCSV(nomeFile);
                        System.out.println("Esportazione avvenuta con successo!");
                    } 
                    catch (IOException ex) 
                    {
                        System.out.println("Errore di scrittura, impossibile accedere al file");
                    } 
                    catch (FileException ex) 
                    {
                        System.out.println("Errore file aperto in lettura!");
                    }
                    break;
                        
               case 8:
                   
                     try 
                    {
                        m1.caricaAbitiCSV(nomeFile);
                        System.out.println("Esportazione avvenuta con successo!");
                    } 
                    catch (IOException ex) 
                    {
                        System.out.println("Errore di scrittura, impossibile accedere al file");
                    } 
                    catch (ClassNotFoundException ex) 
                    {
                        System.out.println("Errore file aperto in lettura!");
                    }
                
                    break;
                case 9:
                  AbitiPresenti=m1.elencoAbitoPresenti();
                  m1.salvaAbitiBinario(nomeFileBinario);
                 System.out.println("Esportazione avvenuta con successo!");
               
                    
                    break;
                case 10:
                  m1.caricaAbitiBinario(nomeFileBinario);
                    System.out.println("Caricamento da file binario effettuato correttamente");
                    break;
            }
         }while (voceScelta != 0);
   
       }
    
 }


   
