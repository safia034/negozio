/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.negozio;

import eccezioni.EccezioneAppendiabitiNonValido;
import eccezioni.EccezionePosizioneNonValida;
import eccezioni.EccezionePosizioneOccupata;
import eccezioni.EccezionePosizioneVuota;
import eccezioni.FileException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import utilita.TextFile;

/**
 *Rappresenta uno magazzino costituito da
 * NUM_Appendiabit , Appendiabiti ciascuna delle quali può 
 * contenere dei Abiti.
 * @author Utente
 */
public class Magazzino implements Serializable
{
    private int appendiabito;
    private Appendiabiti[] appendiabiti; // array di appendiabiti
    private final static int NUM_APPENDIABITI = 5;

    /*
    *Costruttore
    */
    public Magazzino() 
    {
        
        appendiabiti = new Appendiabiti[NUM_APPENDIABITI];
        // Istanzio una mensola (vuota) per ciascun ripiano
        for (int i=0; i < NUM_APPENDIABITI; i++) 
        {
            appendiabiti[i] = new Appendiabiti();
        }
 }
    
    public Magazzino(Magazzino magazino) 
    {
         appendiabiti=new Appendiabiti[NUM_APPENDIABITI];
         Abito ab = null ;
         for(int i=0;i<NUM_APPENDIABITI;i++)
         {
            appendiabiti[i]=new Appendiabiti();
            for (int j=0;j<magazino.getNumMaxAbiti();j++)
            {
                ab=magazino.getAbito(ab); //non fare nulla
                //non fare nulla
                this.setAbito();
            }     
         }
    }
      public Abito getAbito(Abito ab)
    {
        if (appendiabito < 0 || appendiabito >= NUM_APPENDIABITI) 
        {
            
        }
       ab= appendiabiti[appendiabito].getAppendiabiti();
        return ab;
    }

    private Abito setAbito()
    {
        return setAbito();
    }

     /**
     * Restituisce il numero massimo di Abiti
     * contenuti in uno Maggazino
     * @return 
     */
       public int getNumMaxAbiti()
   {
        int contatore=0;
        for (int i=0;i<NUM_APPENDIABITI;i++)
        {
            contatore+=appendiabiti[i].getNumMaxAbiti();
        }
        
        return contatore;
   }

     public String toString()
   {
       String s="";
       for (int i=0;i<NUM_APPENDIABITI;i++)
       {
           s+="appendiabito "+i+":\n"+appendiabiti[i].toString();
       }
       return s;
   }
    public String[] elencoMarcaColore(String colore)
   {
       Abito ab = null;
       String[] elencoMarcaColore = null;
       
       int contaAbitiColore=0;
       for (int i=0;i<NUM_APPENDIABITI;i++)
       {
           for(int j=0;j<appendiabiti[i].getNumMaxAbiti();j++)
           {
               ab=this.getAbito(ab); //Non succederà mai
               //Non succederà mai
               //non fare nulla...
               if (ab.getColore().equalsIgnoreCase(colore))
               {
                   contaAbitiColore++;  //sarà la dimensione dell'array
               }
                
               
           }
       }
 return elencoMarcaColore;
} 
     public Abito[] elencoAbitoPresenti()
   {
       Abito[] elencoAbitoPresenti=new Abito[getNumAbiti()];
       Abito ab = null;
       int c=0; //contatore
       for (int i=0;i<getNumAppendiabiti();i++)
       {
           for(int j=0;j<appendiabiti[i].getNumMaxAppendiabiti();j++)
           {
               ab=getAbito(ab); //non può essere
               //non può essere
               //non fare nulla
               elencoAbitoPresenti[c]=ab;
               c++;
     
           }
       }
       return elencoAbitoPresenti;
   }
     

    public int getAppendiabito() 
    {
        return appendiabito;
    }

    public void setAppendiabito(int appendiabito) 
    {
        this.appendiabito = appendiabito;
    }

    public Appendiabiti[] getAppendiabiti()
    {
        return appendiabiti;
    }
   
    
 /* Inserisce il Abito nella posizione "posizione" del appendiabiti “ripiano”.
        se il appendiabito non è valido --> return -3
        se la posizione non è valida --> return -1
        se la posizione è già occupata --> return -2
        se ok  return 0
    */
    
   public void setAbito(Abito abito, int appendiabito, int posizione) throws EccezioneAppendiabitiNonValido, EccezionePosizioneNonValida, EccezionePosizioneOccupata 
   {
       try
       {
           if (appendiabito < 0 || appendiabito >= NUM_APPENDIABITI) 
    
      throw new EccezioneAppendiabitiNonValido();
        appendiabiti[appendiabito].setAbito(abito, posizione);
 
       }catch(ArrayIndexOutOfBoundsException e)
       {
             throw new eccezioni.EccezionePosizioneNonValida();
       }
    
}

    /**
     * Restituisce il Abito che si trova 
     * in un certo appendiabto, in un certa posizione
     * @param appendiabito 
     * @param posizione 
     * @return 
     * restituisce null se il appendiabito non esiste,
     * se la posizione non esiste oppure se
     * nei dati appendiabiti/posizione non è presente il abito.
     * Negli altri casi restituisce il abito.
     */
public Abito getAbito(int appendiabito, int posizione) throws EccezioneAppendiabitiNonValido, EccezionePosizioneNonValida, EccezionePosizioneVuota
{
    
    if (appendiabito < 0 || appendiabito >= NUM_APPENDIABITI)     
 
        throw new EccezioneAppendiabitiNonValido();
        Abito ab; 
        ab=appendiabiti[appendiabito].getAbito(posizione);
      
    return ab;
}
        /**
     * Rimuove un appendiabito da un determinato appendiabito e una 
     * determinata posizione
     * @param appendiabito 
     * @param posizione
     * @return 
     * se il appendiabtio non è valido --> return -3
     * se la posizione non è valida --> return -1
     * se la posizione è vuota --> return -2
     * se il volume è rimosso correttamente --> return 0
     */

    public void rimuoviAbito(int appendiabito, int posizione ) throws EccezionePosizioneNonValida, EccezionePosizioneVuota, EccezioneAppendiabitiNonValido
    {
        if (appendiabito<0 || appendiabito >=NUM_APPENDIABITI)
            throw new EccezioneAppendiabitiNonValido();
        appendiabiti[appendiabito].rimuoviAbito(posizione);
  
    }
    
    

    /**
     *
     * @param fileName
     * @throws IOException
     * @throws FileException
     * @throws IOException
     * @throws FileException
     */
    public void esportaCSV(String nomeFile) throws IOException, FileException
   {
       TextFile f1=new TextFile(nomeFile,'W');
       Abito ab = null;
       String datiAppendiabito;
       
       for(int i=0;i<getNumAppendiabiti();i++)
       {
           for(int j=0;j<getNumMaxAbiti();j++)
           {
               try 
               {
                   ab=this.getAbito(ab);
                   datiAppendiabito=i+";"+j+";"+ab.getMarca()+";"+ab.getColore()+";"+ab.getPrezzo();
                   f1.toFile(datiAppendiabito);    
               } 
               catch (FileException e) 
               {
                    //non succederà mai
               } 
              
           }
       }
       f1.close();
   }

   /* private int getNumAbiti() {
    int contaAppendiabiti = 0;
    for (int i = 0; i < NUM_APPENDIABITI; i++) 
    {
        contaAppendiabiti = appendiabiti[i].getNumAppendiabiti();
    }
    return contaAppendiabiti;
}
    */
    private int getNumAbiti()  
    {
      int contaAppendiabiti=0;
        for(int i=0;i<NUM_APPENDIABITI;i++)
        {
            contaAppendiabiti+=appendiabiti[i].getNumAppendiabiti();
        }
        return contaAppendiabiti;
        
    }
 /**
     * restituisce il numero di appendiabiti (appendiabito)
     * presenti nello magazzino
     * @return 
     */
    public int getNumAppendiabiti()
    {
        return NUM_APPENDIABITI;
    }
  
  public  Abito[] getAbitiOrdinati()
    {
        
        return null;
        
    }

   public String[] getAbitiMarca(String marca)
    {
        
        return null;
        
    }

  public  void eliminaAbito(int posizione, int appendiabiti)
    {
        
    }

 public   int aggiungiAbito(Abito ab)
    {
        
        return 0;
        
    }
   

 
     public void importaCSV(String nomeFile ) throws IOException, EccezioneAppendiabitiNonValido, EccezionePosizioneNonValida, EccezionePosizioneOccupata
   {
       TextFile f1=new TextFile(nomeFile,'R');
       String  rigaletta;
       String marca, tipo = null,colore,taglia = null;
       int prezzo,idAbito = 0, posizione;
       Abito ab;
       String[] datiAbito;
     
       
 try {
        while(true)
         {    
            rigaletta=f1.fromFile();
            datiAbito=rigaletta.split(";");
            appendiabito=Integer.parseInt(datiAbito[0]);
            posizione=Integer.parseInt(datiAbito[1]);
            marca=datiAbito[2];
            colore=datiAbito[3];
            
            prezzo=Integer.parseInt(datiAbito[4]);
            ab=new Abito(idAbito, tipo, prezzo, marca, taglia, colore);
           try
           { 
             
               this.setAbito(ab, appendiabito, posizione);
           } 
           catch (EccezioneAppendiabitiNonValido ex)
           {
               //non fa nulla, il libro non viene messo nello scaffale
           } 
          
                    
        }
    }
    catch (FileException ex)
     {
            // è  finito file di testo
         f1.close();
     }
   }
    
 
 public void salvaAbitiCSV(String nomeFile) throws FileNotFoundException, IOException
   {
       ObjectOutputStream writer=new ObjectOutputStream(new FileOutputStream(nomeFile));
       writer.writeObject(this);
       writer.flush();
       writer.close();
    }

   public Magazzino caricaAbitiCSV(String nomeFile) throws FileNotFoundException, IOException, ClassNotFoundException 
   {
      Magazzino m;
      ObjectInputStream reader=new ObjectInputStream(new FileInputStream(nomeFile));
      m=(Magazzino) reader.readObject();
      reader.close();
      return m ;
    }

  public  Magazzino caricaAbitiBinario(String nomeFileBinario) throws FileNotFoundException, IOException, ClassNotFoundException 
    {
      Magazzino m;
      ObjectInputStream reader=new ObjectInputStream(new FileInputStream(nomeFileBinario));
      m=(Magazzino) reader.readObject();
      reader.close();
      return m;
    }

   public void salvaAbitiBinario(String nomeFileBinario) throws FileNotFoundException, IOException
    {
        ObjectOutputStream writer=new ObjectOutputStream(new FileOutputStream(nomeFileBinario));
       writer.writeObject(this);
       writer.flush();
       writer.close();
    }


 
 
}


    
   
    


   