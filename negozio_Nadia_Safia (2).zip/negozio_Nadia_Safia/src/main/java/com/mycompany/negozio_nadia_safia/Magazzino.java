/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.negozio_nadia_safia;

import com.mycompany.negozio_nadia_safia.Abito;
import eccezioni.EccezioneAppendiabitiNonValido;
import eccezioni.EccezionePosizioneNonValida;
import eccezioni.EccezionePosizioneOccupata;
import eccezioni.EccezionePosizioneVuota;

/**
 *
 * @author Studente
 */
public class Magazzino
{
    private Appendiabiti[] appendiabiti; //array di appendiabiti
    private final static int NUM_APPENDIABITI=5;
    
    public Magazzino()
    {
        appendiabiti=new Appendiabiti[NUM_APPENDIABITI];
        //Istanzio una mensola (vuota) per ciascun ripiano
        for(int i=0;i<NUM_APPENDIABITI;i++)
        {
            appendiabiti[i]=new Appendiabiti();
        }
    }
    
    public Magazzino(Magazzino mag) 
    {
         appendiabiti=new Appendiabiti[NUM_APPENDIABITI];
         Abito ab;
         for(int i=0;i<NUM_APPENDIABITI;i++)
         {
            appendiabiti[i]=new Appendiabiti();
            for (int j=0;j<mag.getNumMaxAbiti(i);j++)
            {
                try 
                {
                    ab=mag.getAbito(i, j);
                    this.setAbito(ab, i, j);
                } 
                catch (EccezioneAppendiabitiNonValido ex) 
                {
                    //Non può essere
                } 
                catch (EccezionePosizioneNonValida ex) 
                {
                    //non può essere
                } 
                catch (EccezionePosizioneVuota ex) 
                {
                    //non fare nulla
                }
                catch (EccezionePosizioneOccupata ex) 
                {
                    //non fare nulla
                }
            }     
         }
    }
    
      public void setAbito(Abito abito, int appendiabiti, int posizione ) throws EccezioneAppendiabitiNonValido, EccezionePosizioneNonValida, EccezionePosizioneOccupata 
    {
        
        if (appendiabiti<0 || appendiabiti >=NUM_APPENDIABITI)
            throw new EccezioneAppendiabitiNonValido();
        appendiabiti[appendiabiti].setAbito(appendiabiti, posizione);
    }
      
        public Abito getAbito(int appendiabiti, int posizione) throws EccezioneAppendiabitiNonValido, EccezionePosizioneNonValida, EccezionePosizioneVuota
    {
        if (appendiabiti<0 || appendiabiti>=NUM_APPENDIABITI)
            throw new EccezioneAppendiabitiNonValido();
        Abito ab;
        ab=appendiabiti[appendiabiti].getAppendiabiti(posizione);
        return ab;
    }

         public void rimuoviAbito(int appendiabiti, int posizione ) throws EccezioneAppendiabitiNonValido, EccezionePosizioneNonValida, EccezionePosizioneVuota
    {
       
        if (appendiabiti<0 || appendiabiti >=NUM_APPENDIABITI)
            throw new EccezioneAppendiabitiNonValido();
        appendiabiti[appendiabiti].rimuoviAbitiposizione);
}
         
           public int getNumAppendiabiti()
    {
        return NUM_APPENDIABITI;
    }
    
  
    public int getNumMaxAbiti()
    {
        int contatore=0;
        for (int i=0;i<NUM_APPENDIABITI;i++)
        {
            contatore+=appendiabiti[i].getNumMaxAbiti();
        }
        
        return contatore;
    }
    
    
    public int getNumAbiti()
    {
        int contaVolumi=0;
        for(int i=0;i<NUM_APPENDIABITI;i++)
        {
            contaVolumi+=appendiabiti[i].getNumAbiti();
        }
        return contaVolumi;
    }
    
    
}
