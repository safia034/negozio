/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.negozio_nadia_safia;

/**
 *
 * @author Studente
 */
public class App
{

    public static void main(String[] args)
    {
        
    }
}
