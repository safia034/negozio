/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.negozio_smnd;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Studente
 */
public class AbitoTest {
    
    public AbitoTest() {
    }

    /**
     * Test of getIdAbito method, of class Abito.
     */
    @Test
    public void testGetIdAbito() {
    }

    /**
     * Test of setIdAbito method, of class Abito.
     */
    @Test
    public void testSetIdAbito() {
    }

    /**
     * Test of getTipo method, of class Abito.
     */
    @Test
    public void testGetTipo() {
    }

    /**
     * Test of setTipo method, of class Abito.
     */
    @Test
    public void testSetTipo() {
    }

    /**
     * Test of getPrezzo method, of class Abito.
     */
    @Test
    public void testGetPrezzo() {
    }

    /**
     * Test of setPrezzo method, of class Abito.
     */
    @Test
    public void testSetPrezzo() {
    }

    /**
     * Test of getMarca method, of class Abito.
     */
    @Test
    public void testGetMarca() {
    }

    /**
     * Test of setMarca method, of class Abito.
     */
    @Test
    public void testSetMarca() {
    }

    /**
     * Test of getTaglia method, of class Abito.
     */
    @Test
    public void testGetTaglia() {
    }

    /**
     * Test of setTaglia method, of class Abito.
     */
    @Test
    public void testSetTaglia() {
    }

    /**
     * Test of getColore method, of class Abito.
     */
    @Test
    public void testGetColore() {
    }

    /**
     * Test of setColore method, of class Abito.
     */
    @Test
    public void testSetColore() {
    }

    /**
     * Test of toString method, of class Abito.
     */
    @Test
    public void testToString() {
    }
    
}
