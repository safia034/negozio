import com.mycompany.negozio_smnd.*;
import eccezioni.*;
import java.util.ArrayList;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
 
public class AppendiabitiTest {
 
    private Appendiabiti appendiabiti;
 
    @BeforeEach
    public void setUp() 
    {
        appendiabiti = new Appendiabiti();
    }
 
   
 
    @Test
    public void testAggiungiAbitoPosizioneNonValida() 
    {
        Abito abito = new Abito(1, "Maglietta", 20.50f, "Zara", "M", "Verde");
 
        try {
            appendiabiti.setAbito(abito, appendiabiti.getNumMaxAbiti());
            fail("Aggiunto abito in posizione non valida");
        } catch (EccezionePosizioneNonValida e) {
            // Test superato
        } catch (EccezionePosizioneOccupata e) {
            fail("Eccezione errata: " + e.getMessage());
        }
    }
 
    @Test
    public void testAggiungiAbitoPosizioneOccupata() 
    {
        Abito abito1 = new Abito(1, "Maglietta", 20.50f, "Zara", "M", "Verde");
        Abito abito2 = new Abito(2, "Jeans", 45.00f, "Levi's", "38", "Blu");
 
        try {
            appendiabiti.setAbito(abito1, 0);
            appendiabiti.setAbito(abito2, 0);
            fail("Aggiunto abito in posizione già occupata");
        } catch (EccezionePosizioneNonValida e) {
            fail("Eccezione errata: " + e.getMessage());
        } catch (EccezionePosizioneOccupata e) {
            // Test superato
        }
    }
 
    @Test
    public void testRimuoviAbitoPosizioneValida() throws EccezionePosizioneOccupata 
    {
        Abito abito = new Abito(1, "Maglietta", 20.50f, "Zara", "M", "Verde");
 
        try {
            appendiabiti.setAbito(abito, 0);
            appendiabiti.rimuoviAbito(0);
            assertNull(appendiabiti.getAbito(0));
        } catch (EccezionePosizioneNonValida | EccezionePosizioneVuota e) 
        {
            
        }
    }
 
    @Test
    public void testRimuoviAbitoPosizioneNonValida() 
    {
        try {
            appendiabiti.rimuoviAbito(appendiabiti.getNumMaxAbiti());
            fail("Rimosso abito in posizione non valida");
        } catch (EccezionePosizioneNonValida e)
        {
            // Test superato
        } catch (EccezionePosizioneVuota e) {
            fail("Eccezione errata: " + e.getMessage());
        }
    }
 
    @Test
    public void testRimuoviAbitoPosizioneVuota()
    {
        try {
            appendiabiti.rimuoviAbito(0);
            fail("Rimosso abito da posizione vuota");
        } catch (EccezionePosizioneNonValida e) 
        {
            fail("Eccezione errata: " + e.getMessage());
        } catch (EccezionePosizioneVuota e) 
        {
            // Test superato
        }
    }
 
    @Test
    public void testGetAbitoPosizioneValida() 
    {
        Abito abito = new Abito(1, "Maglietta", 20.50f, "Zara", "M", "Verde");
        
    }
     public void testElencoAbitiMarca() throws Exception
    {
        Abito abito1=new Abito(1, "Felpa", 22.95f, "Lacoste", "M", "Blu");
        Abito abito2=new Abito(2, "Giacca", 27.00f, "Adidas", "L", "Nero");
        Appendiabiti app=new Appendiabiti();
        app.setAbito(abito1, 0);
        app.setAbito(abito2, 0);
        String s[]={abito1.getMarca(), abito2.getMarca()};
        assertArrayEquals(s,app.elencoAbitiMarca("Lacoste"));
    }
     
}