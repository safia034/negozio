/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */


import com.mycompany.negozio_smnd.Abito;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Studente
 */
public class AbitoTest {
    
    public AbitoTest()
    {
       
    }

    /**
     * Test of getIdAbito method, of class Abito.
     */
    @Test
    public void testsetIdAbito() 
    {
        Abito abito=new Abito(0, "Maglietta", 23.0f, "Zara", "L", "Nero");
        abito.setIdAbito(0);
        assertEquals(0,abito.getIdAbito());
    }

    /**
     * Test of setIdAbito method, of class Abito.
     */

    @Test
    public void testsetTipo() 
    {
         Abito abito=new Abito(0, "Maglietta", 23.0f, "Zara", "L", "Nero");
        abito.setTipo("Maglietta");
        assertEquals("Maglietta",abito.getTipo());
    }

    /**
     * Test of setTipo method, of class Abito.
     */
    @Test
    public void testsetPrezzo()
    {
         Abito abito=new Abito(0, "Maglietta", 23.0f, "Zara", "L", "Nero");
        abito.setPrezzo(23.0f);
        assertEquals(23.0f,abito.getPrezzo());
    }

    
    /**
     * Test of getMarca method, of class Abito.
     */
    @Test
    public void testsetMarca()
    {
         Abito abito=new Abito(0, "Maglietta", 23.0f, "Zara", "L", "Nero");
        abito.setMarca("Zara");
        assertEquals("Zara",abito.getMarca());
    }
    

    /**
     * Test of setMarca method, of class Abito.
     */
  
    @Test
    public void testsetTaglia()
    {
         Abito abito=new Abito(0, "Maglietta", 23.0f, "Zara", "L", "Nero");
        abito.setTaglia("L");
        assertEquals("L",abito.getTaglia());
    }

    /**
     * Test of getColore method, of class Abito.
     */
    @Test
    public void testsetColore() 
    {
         Abito abito=new Abito(0, "Maglietta", 23.0f, "Zara", "L", "Nero");
        abito.setColore("Nero");
        assertEquals("Nero",abito.getColore());
    }

   
}
