/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.negozio;

import eccezioni.EccezioneAppendiabitiNonValido;
import eccezioni.EccezionePosizioneNonValida;
import eccezioni.EccezionePosizioneOccupata;
import eccezioni.EccezionePosizioneVuota;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Utente
 */
public class Magazzino implements Serializable
{
    private int appendiabito = 0;
    private Appendiabiti[] appendiabiti; // array di appendiabiti
    private final static int NUM_APPENDIABITI = 5;

    public Magazzino() 
    {
        appendiabiti = new Appendiabiti[NUM_APPENDIABITI];
        // Istanzio una mensola (vuota) per ciascun ripiano
        for (int i = 0; i < NUM_APPENDIABITI; i++) 
        {
            appendiabiti[i] = new Appendiabiti();
        }
 }
    
    public Magazzino(Magazzino magazino) 
    {
         appendiabiti=new Appendiabiti[NUM_APPENDIABITI];
         Abito ab = null;
         for(int i=0;i<NUM_APPENDIABITI;i++)
         {
            appendiabiti[i]=new Appendiabiti();
            for (int j=0;j<magazino.getNumMaxAbiti();j++)
            {
                ab=magazino.getAbito(ab); //non fare nulla
                //non fare nulla
                this.setAbito();
            }     
         }
    }
      public Abito getAbito(Abito ab)
    {
        if (appendiabito < 0 || appendiabito >= NUM_APPENDIABITI) 
        {
            
        }
       ab= appendiabiti[appendiabito].getAppendiabiti();
        return ab;
    }

    private Abito setAbito()
    {
        return setAbito();
    }


       public int getNumMaxAbiti()
   {
        int contatore=0;
        for (int i=0;i<NUM_APPENDIABITI;i++)
        {
            contatore+=appendiabiti[i].getNumMaxAbiti();
        }
        
        return contatore;
   }

     public String toString()
   {
       String s="";
       for (int i=0;i<NUM_APPENDIABITI;i++)
       {
           s+="Ripiano "+i+":\n"+appendiabiti[i].toString();
       }
       return s;
   }
    public String[] elencoMarcaColore(String colore)
   {
       Abito ab = null;
       String[] elencoMarcaColore = null;
       
       int contaLibriAutore=0;
       for (int i=0;i<NUM_APPENDIABITI;i++)
       {
           for(int j=0;j<appendiabiti[i].getNumMaxAbiti();j++)
           {
               ab=this.getAbito(ab); //Non succederà mai
               //Non succederà mai
               //non fare nulla...
               if (ab.getColore().equalsIgnoreCase(colore))
               {
                   contaLibriAutore++;  //sarà la dimensione dell'array
               }
                
               
           }
       }
 return elencoMarcaColore;
} 
     public Abito[] elencoAbitoPresenti()
   {
       Abito[] elencoAbitoPresenti=new Abito[getNumAbiti()];
       Abito ab = null;
       int c=0; //contatore
       for (int i=0;i<getNumAppendiabiti();i++)
       {
           for(int j=0;j<appendiabiti[i].getNumMaxAppendiabiti();j++)
           {
               ab=getAbito(ab); //non può essere
               //non può essere
               //non fare nulla
               elencoAbitoPresenti[c]=ab;
               c++;
     
           }
       }
       return elencoAbitoPresenti;
   }
     

    public int getAppendiabito() 
    {
        return appendiabito;
    }

    public void setAppendiabito(int appendiabito) 
    {
        this.appendiabito = appendiabito;
    }

    public Appendiabiti[] getAppendiabiti()
    {
        return appendiabiti;
    }
   
    
  
   public void setAbito(Abito abito, int appendiabito, int posizione) throws EccezioneAppendiabitiNonValido 
   {
    if (appendiabito < 0 || appendiabito >= NUM_APPENDIABITI) {
        throw new EccezioneAppendiabitiNonValido();
    }
        try {
            appendiabiti[appendiabito].setAbito(abito, posizione);
        } catch (EccezionePosizioneNonValida ex) {
        } catch (EccezionePosizioneOccupata ex) {
            Logger.getLogger(Magazzino.class.getName()).log(Level.SEVERE, null, ex);
        }
}

public Abito getAbito(int appendiabito, int posizione) throws EccezioneAppendiabitiNonValido
{
    Abito ab = null;
    if (appendiabito < 0 || appendiabito >= NUM_APPENDIABITI) 
        {
        // Gestisci l'eccezione qui o propagala verso l'alto
        // ad esempio, puoi loggare un messaggio di errore o lanciare un'altra eccezione
        // a seconda delle tue esigenze.
        throw new EccezioneAppendiabitiNonValido();
    }
        try 
        {
            ab = appendiabiti[appendiabito].getAbito(posizione);
        }
        catch (EccezionePosizioneNonValida ex) 
        {
            
        }
        catch (EccezionePosizioneVuota ex)
        {
            
        }
    return ab;
}

    public void rimuoviAbito(int appendiabito, int posizione ) throws EccezionePosizioneNonValida, EccezionePosizioneVuota
    {
        if (appendiabito<0 || appendiabito >=NUM_APPENDIABITI)
            
        appendiabiti[appendiabito].rimuoviAbito(posizione);
  
    }

   /* private int getNumAbiti() {
    int contaAppendiabiti = 0;
    for (int i = 0; i < NUM_APPENDIABITI; i++) 
    {
        contaAppendiabiti = appendiabiti[i].getNumAppendiabiti();
    }
    return contaAppendiabiti;
}
    */
    private int getNumAbiti()  
    {
      int contaAppendiabiti=0;
        for(int i=0;i<NUM_APPENDIABITI;i++)
        {
            contaAppendiabiti+=appendiabiti[i].getNumAppendiabiti();
        }
        return contaAppendiabiti;
        
    }

    public int getNumAppendiabiti()
    {
        return getNumAppendiabiti();
    }
   
  public  Abito[] getAbitiOrdinati()
    {
        
        return null;
        
    }

   public String[] getAbitiMarca(String marca)
    {
        
        return null;
        
    }

  public  void eliminaAbito(int posizione, int appendiabiti)
    {
        
    }

 public   int aggiungiAbito(Abito ab)
    {
        
        return 0;
        
    }


   
    
}

   